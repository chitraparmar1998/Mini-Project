<?php

include('config.php');					
					if(isset($_SESSION['email'])){?>
									<?php
					}
					else 
					{
					header("Location: admin_login.php");

					}
					?>	
<?php 
include('config.php');
if(isset($_GET['edit'])){
$staff_id = $_GET['edit'];
$query ="SELECT * FROM staff where staff_id = '$staff_id'";

$result=mysql_query($query);
while($row=mysql_fetch_array($result)){
   
    ?>  

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/admin_panel.css" rel="stylesheet">
	<style>
.dropbtn {
  background-color: #222;
  color: white;
  padding: 16px;
  font-size: 14px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>

    <title>Staff Update</title>
  </head>

  <body>


 <?php
	include('menu.php');
	
	?>
		<header id="header">
		<div class="container">
			<div class="row">
				<div class="col-md-10">
					<h1><span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Staff Details Update</small></h1>
				</div>
			</div>
		</div>
	</header>
	
	<section id="breadcrumb">
		<div class="container">
			<ol class="breadcrumb">
				<li>Admin Panel</li>
				<li class="active">Staff Details Update</li>
		</ol>
		</div>
	</section>
	


	<section id="main">
		<div class="container">
			<div class="row">
				<div class="col-md-12"><!-- website overview -->
					<div class="panel panel-default">
					  <div class="panel-heading main-color-bg">
						<h3 class="panel-title">Staff Details Update</h3>
					 </div>
					</div>
					<!-- latest user -->
					<div class="panel panel-default">
					  <div class="panel-body">
						<div class="table-responsive">
						<form action="staff_update_process.php" method="post" enctype="multipart/form-data">
							<div class="rows">
								
								
									<div class="form-group text-left col-md-6">
										<label>Staff ID :</label>
										<input class="form-control" type="text" value="<?php echo $row['staff_id'];?>" name="staff_id" readonly required>
									</div>
									
									<div class="form-group text-left col-md-6">
										<label>Staff Name :</label>
										<input class="form-control" type="text" value="<?php echo $row['staff_name'];?>" name="staff_name" required>
									</div>
									
									<div class="form-group text-left col-md-6">
										<label>Designation :</label>
										<input class="form-control" type="text" value="<?php echo $row['designation'];?>" name="Designation" required>
									</div>
									<div class="form-group text-left col-md-6">
										<label>Email :</label>
										<input class="form-control" type="text" value="<?php echo $row['email'];?>" name="femail" required>
									</div>
									
								
									<div class="form-group text-left col-md-6">
										<label>Mobile No :</label>
										<input class="form-control" type="text" value="<?php echo $row['mobile_no'];?>" name="mobile" required>
									</div>
										<div class="form col-md-6">
										<label>Gender :</label>&nbsp&nbsp&nbsp
										Male&nbsp&nbsp&nbsp <input class="control"  value="male"  type="radio" <?php if ($row["gender"]=='male'){echo "checked";}?> name="gender" >&nbsp&nbsp&nbsp
										Female&nbsp&nbsp&nbsp <input class="control"  value="female" <?php if ($row["gender"]=='female'){echo "checked";}?> type="radio" name="gender" >
				
										</div>
								
	

									<br><br><br><br>
									<div class="form-group text-left col-md-4">
										<input class="btn btn-primary" type="submit" name="update" value="submit">
									<!--MSG PASS-------->
										<h4 style="color:red;">
										<?php 
										  if (isset($_GET['msg'])) echo $_GET['msg'];
											
										?>
										
											</h4>							
								
									</div>
									<?php
								}
								}
								?>
		
								</div>
							</form>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	
	
	<!-- Modal -->
		<div class="modal fade" id="addpage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form>
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Page</h4>
				  </div>
				  <div class="modal-body">
					...
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary">Save changes</button>
				  </div>
				 </form> 
			</div>
		  </div>
		</div>
	<!-- footer -->
	
	
  </body>
</html>
