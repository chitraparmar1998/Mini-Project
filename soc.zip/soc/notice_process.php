
<?php include('config.php');

if($_POST['reg']=='submit')
	{  
		$system_date=$_POST['system_date'];
	
	$notice_subject=$_POST['notice_subject'];
	$notice_con =$_POST['notice_con'];
	$date=$_POST['date'];
	$time=$_POST['time'];
	$notice_sender_name=$_POST['notice_sender_name'];
	$notes=$_POST['notes'];
	
	


	$sql="INSERT INTO notice(notice_subject,notice_con,date,time,notice_sender_name,notes,system_date)
	VALUES('$notice_subject','$notice_con','$date','$time','$notice_sender_name','$notes','$system_date')";
	$result = mysql_query($sql);
	echo $sql;
 if($result)
	{
  

		$msg="Successfully Send Notice...";
		header("location:notice_send.php?msg=".$msg);
	
} 
    else
    {
		$msg="You ve already Send..";
		header("location:notice_send.php?msg=".$msg);
	
			
    }
	}
		
    
	
?>