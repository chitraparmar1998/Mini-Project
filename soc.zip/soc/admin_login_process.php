<?php
session_start();

include('config.php');
	
	$femail=$_POST['femail'];
	$fpass=$_POST['fpass'];
		
	
	$femail=stripcslashes($femail);
	$fpass=stripcslashes($fpass);
	
	
	$femail=mysql_real_escape_string($femail);
	$fpass=mysql_real_escape_string($fpass);
	
	$sql="SELECT * FROM admin_login where email='$femail' and password='$fpass'";
	//echo $sql;
	$result=mysql_query($sql);
		
		if(mysql_num_rows($result)==1){
		while ($row=mysql_fetch_array($result)){
		$_SESSION['email']=$row['email'];
	
		$_SESSION['email']=$femail;
	
				//$msg="You Successfully Login...";
				header("location:index.php?You Successfully Login...".$msg);
		}
		}
		
		else
		{
			$msg="Invalid ID & Password... ";
			header("location:admin_login.php?msg=".$msg);
			
		}

	?>