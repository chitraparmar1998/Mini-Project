
<?php include('config.php');

if($_POST['reg']=='submit')
	{  
	$staff_name=$_POST['staff_name'];
	$designation =$_POST['Designation'];
	$email=$_POST['femail'];
	$mobile=$_POST['mobile'];
	$gender=$_POST['gender'];
	
	


	$sql="INSERT INTO staff(staff_name,designation,email,mobile_no,gender)VALUES('$staff_name','$designation','$email','$mobile','$gender')";
	$result = mysql_query($sql);
	echo $sql;
 if($result)
	{
  

		$msg="Successfully Registration Member...";
		header("location:staff.php?msg=".$msg);
	
} 
    else
    {
		$msg="You ve already Registration..";
		header("location:staff.php?msg=".$msg);
	
			
    }
	}
		
    
	
?>