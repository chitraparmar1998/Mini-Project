<?php
// edit data update 
if (isset($_POST['update']))
{

include ('config.php');
	$member_id=$_POST['m_id'];
	$m_name=$_POST['m_name'];
	$email=$_POST['m_email'];
	$address=$_POST['address'];
	$password=$_POST['password'];
	$total_member=$_POST['total_member'];
	$gender=$_POST['gender'];
	$house_type=$_POST['house_type'];
	$mobile=$_POST['mobile'];


$sql="UPDATE member_reg SET member_name='$m_name',email='$email',address='$address',password='$password',total_member='$total_member',gender='$gender',house_type='$house_type',mobile='$mobile' WHERE member_id='$member_id'";
	 
		echo $sql;
	
	$result=mysql_query($sql);	
	if ($result)
	{
		header("location:member_show.php?Successfully Update..");
	}
	else 
	{
		echo "<script>alert('Sorry You already Update Data')</script>";
	
	}
	}
	?>

