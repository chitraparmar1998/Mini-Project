

<?php 
include('config.php');

    ?>
	<!--
Au<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Planet Hosting a Hosting Category Flat Bootstrap Responsive Website Template | Login :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 80%;
  
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
	<!---header--->
		<?php
	include('menu.php');
	
	?>

	<h1 align ="center" font style="arial"><b>Notice View</b></h1><br>
						
<table id="customers" align="center">
  <tr>
									<th width="12%">Notice Number</th>
									<th>Notice Subject</th>
									<th width="15%">Notice Declare Date</th>
									<th width="12%">View Notice</th>
  </tr>
  							<?php 
				include('config.php');

				$query ="SELECT * FROM notice";

				$result=mysql_query($query);

				while($row=mysql_fetch_array($result)){
 	 
    ?>   
  <tr>
  <td ><?php echo $row['notice_id'];?></td>
  <td ><?php echo $row['notice_subject'];?></td>
	<td ><?php echo $row['system_date'];?></td>						
  <td ><a href="fpdf/demo.php?edit=<?php echo $row['notice_id'];?> &name=<?php echo $_SESSION['email'];?>">View</td>
  
  </tr>
  
<?php
		}
		     
		
	?>
							
</table>
	
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!-- login -->
				<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div>
				<!---footer--->
</body>
</html>