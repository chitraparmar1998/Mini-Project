
	<div class="header">
			<div class="container">
				<nav class="navbar navbar-default">
					<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
								<i class="sr-only">Toggle navigation</i>
								<i class="icon-bar"></i>
								<i class="icon-bar"></i>    
								<i class="icon-bar"></i>
							</button>				  
							<div class="navbar-brand">
								<h1><a href="index.php"><img src="new_image/smartlogo.jpg" height="90" width="90">Smart Society</a></h1>
							</div>
						</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<?php
							if (isset($_GET['menu'])){
								$menu = $_GET['menu'];
							}
						?>
							<ul class="nav navbar-nav">
			<li class="<?php if($menu == 'Home' ){ echo 'active'; } ?>"><a href="index.php?menu=<?php echo 'Home'; ?>">Home</a></li>
			<li class="<?php if($menu == 'facilities' ){ echo 'active'; } ?>"><a href="facilities.php?menu=<?php echo 'facilities'; ?>">Facilities</a></li>
			<li class="<?php if($menu == 'Hall_Bokking' ){ echo 'active'; } ?>"><a href="hall_booking.php?menu=<?php echo 'Hall_Bokking'; ?>">Hall Booking</a></li>
			<li class="<?php if($menu == 'gallery' ){ echo 'active'; } ?>"><a href="gallery.php?menu=<?php echo 'gallery'; ?>">Photo Gallery</a></li>
			<li class="<?php if($menu == 'FeedBack' ){ echo 'active'; } ?>"><a href="feedback.php?menu=<?php echo 'FeedBack'; ?>">FeedBack</a></li>
								
								
									
								<?php
								
				if(isset($_SESSION['email'])){?>
			
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My Account <i class="caret"></i></a>
										<ul class="dropdown-menu">
											<li><a href="notice.php">View Notice</a></li>
											<li><a href="maintenanc_view.php">View Maintenance</a></li>
											<li><a href="complain.php">Complaint</a></li>
											
											<li><a href="my_account.php">My Account Details</a></li>
											<li><a href="logout_member.php">Logout</a></li>
										</ul>     
									</li>
									<label> <?php echo 'Welcome- '.$_SESSION['member_name'];?> </label>
				
						<?php
								}
						else
								{
					?>			
									<li><a href="login_member.php">Member Login</a></li>
		
<?php
}

?>	
								
															</ul>
									  
						</div><!-- /.navbar-collapse -->
					</div><!-- /.container-fluid -->
				</nav>
			</div>
		</div>