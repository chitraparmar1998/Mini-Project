<?php
// edit data update 
include ('config.php');
	

if (isset($_POST['edit']))
{

	
		$member_name=$_POST['m_name'];
	$email=$_POST['m_email'];
	$mobile=$_POST['mobile'];
	$total_member=$_POST['total_member'];
	$password=$_POST['password'];
	

$sql="UPDATE member_reg SET member_name='$member_name', mobile='$mobile', total_member='$total_member', password='$password' WHERE email='$email'";
	 
	 	echo $sql;
	
	$result=mysql_query($sql);	
	if ($result)
	{
		header("location:my_account.php?Successfully Update..");
	}
	else 
	{
		echo "<script>alert('Sorry You already Update Data')</script>";
	
	}
	}
	?>

