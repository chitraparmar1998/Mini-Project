<?php
session_start();

include('config.php');
	
	$femail=$_POST['femail'];
	$fpass=$_POST['fpass'];
		
	
	$femail=stripcslashes($femail);
	$fpass=stripcslashes($fpass);
	
	  
	$femail=mysql_real_escape_string($femail);
	$fpass=mysql_real_escape_string($fpass);
	
	$sql="SELECT * FROM member_reg where email='$femail' and password='$fpass'";
	//echo $sql;
	$result=mysql_query($sql);
		
		if(mysql_num_rows($result)==1)
		{
		    
		while ($row=mysql_fetch_array($result)){
	    	$_SESSION['member_name']=$row['member_name'];
        	$_SESSION['mobile']=$row['mobile'];
	    	$_SESSION['house_type']=$row['house_type'];
	    	$_SESSION['email']=$femail;

	    
				//$msg="You Successfully Login...";
				
				header("location:index.php?You Successfully Login...".$msg);
		}
		}
		
		else
		{
			$msg="Invalid ID & Password... ";
			header("location:login_member.php?msg=".$msg);
			
		}

	?>