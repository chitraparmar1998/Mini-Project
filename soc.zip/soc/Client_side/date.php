<?php
$date1 = "12-1-12";
$date2 = "12-1-12";
	
if ($date1 !== $date2)
echo "Bokking This Date";	
else
 
 echo "Sorry Date Alreday Book ";
?>