
<?php include('config.php');

if($_POST['reg']=='submit')
	{  
	$name=$_POST['name'];
	$email =$_POST['email'];
	$mobile=$_POST['number'];
	$msg=$_POST['msg'];
	$date=$_POST['date'];
	
	


	$sql="INSERT INTO complain(name,email,mobile,msg,date)VALUES('$name','$email','$mobile','$msg','$date')";
	$result = mysql_query($sql);
	echo $sql;
 if($result)
	{
  

		$msg="Successfully Complain...";
		header("location:complain.php?msg=".$msg);
	
} 
    else
    {
		//$msg="Sorry..............";
	///	header("location:feedback.php?msg=".$msg);
	
			
    }
	}
		
    
	
?>