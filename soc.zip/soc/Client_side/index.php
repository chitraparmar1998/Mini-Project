
<?php
	include ('config.php')
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Index</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<script src="js/modernizr.custom.97074.js"></script>
<script src="js/jquery.chocolat.js"></script>
<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="screen">
<!--lightboxfiles-->
<script type="text/javascript">
	$(function() {
	$('.team a').Chocolat();
	});
</script>	
<script type="text/javascript" src="js/jquery.hoverdir.js"></script>	
						<script type="text/javascript">
							$(function() {
							
								$(' #da-thumbs > li ').each( function() { $(this).hoverdir(); } );

							});
						</script>
						<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!--script-->
</head>
<body>
	<!---header--->
		<?php
	include('menu.php');
	
	?>

	<!---banner--->
		<div class="banner">
			<div class="container">
				<div class="banner-grids">
					<div class="col-md-6 banner-grid">
						<img src="new_image/c2.jpg" width="600" height="300"  alt=""/>
					</div>
					<div class="col-md-6 banner-grid">
						<h3>Smart Society </h3>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	<!---banner--->
	<!---brilliantly --->
			<div class="content">
				<div class="brilliant-section">
					<div class="container">
						<h2>Facilities Available on </h2></h2>
						<div class="brilliant-grids">
							<div class="col-md-4 brilliant-grid">
								<div class="brilliant-left">
								<i class="fa fa-bathtub" aria-hidden="true"></i>
								</div>
								<div class="brilliant-right">
									<h4>Swimming Pool</h4>
									<p>I only really and truly fully relax on my own. Give me a sun lounger, a pool and a sea view, and I'm happy.</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="col-md-4 brilliant-grid">
								<div class="brilliant-left">
								<i class="glyphicon glyphicon-fire" aria-hidden="true"></i>
									</div>
								<div class="brilliant-right">
									<h4>fire Protection</h4>
									<p>In everyone's life, at some time, our inner fire goes out. It is then burst into flame by an encounter with another human being. We should all be thankful for those people who rekindle the inner spirit.</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="col-md-4 brilliant-grid">
								<div class="brilliant-left">
								<i class="fa fa-wifi" aria-hidden="true"></i>
								</div>
								<div class="brilliant-right">
									<h4>Wifi  Service</h4>
									<p>The free market for mobile devices and wireless service has been a dramatic success.</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="brilliant-grids">
							<div class="col-md-4 brilliant-grid">
								<div class="brilliant-left">
								<i class="fa fa-gamepad" aria-hidden="true"></i>
								</div>
								<div class="brilliant-right">
									<h4>Games Room</h4>
									<p>Life is a song - sing it. Life is a game - play it. Life is a challenge - meet it. Life is a dream - realize it. Life is a sacrifice - offer it. Life is love - enjoy it.</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="col-md-4 brilliant-grid">
								<div class="brilliant-left">
								<i class="glyphicon glyphicon-link" aria-hidden="true"></i>
								</div>
								<div class="brilliant-right">
									<h4>GYM</h4>
									<p>For me, fitness is not just about hitting the gym; it is also about an inner happiness and an overall well-being.</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="col-md-4 brilliant-grid">
								<div class="brilliant-left">
								<i class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></i>
								</div>
								<div class="brilliant-right">
									<h4>Landscaped Gardens</h4>
									<p>Love is like a beautiful flower which I may not touch, but whose fragrance makes the garden a place of delight just the same.</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
			<!---brilliantly--->
			<!---team--->
				<div class="team">
					<h3>our team is one of the best</h3>
					<h5>Professionals that are always on top of their game</h5>
					<div class="team-grids">
						<section>
							<ul id="da-thumbs" class="da-thumbs">
								<li>
									<a href="images/t1.jpg" class="b-link-stripe b-animate-go thick box">
										<img src="images/t1.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
								<li>
									<a href="images/t2.jpg" class="b-link-stripe b-animate-go  thick box">
										<img src="images/t2.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
								<li>
									<a href="images/t3.jpg" class="b-link-stripe b-animate-go  thick box">
										<img src="images/t3.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
								<li>
									<a href="images/t4.jpg" class="b-link-stripe b-animate-go  thick box">
										<img src="images/t4.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
								<li>	
									<a href="images/t5.jpg" class="b-link-stripe b-animate-go  thick box">
										<img src="images/t5.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
								<li>
									<a href="images/t6.jpg" class="b-link-stripe b-animate-go  thick box">
										<img src="images/t6.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
								<li>
									<a href="images/t7.jpg" class="b-link-stripe b-animate-go  thick box">
										<img src="images/t7.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
								<li>
									<a href="images/t8.jpg" class="b-link-stripe b-animate-go  thick box">
										<img src="images/t8.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
								<li>
									<a href="images/t9.jpg" class="b-link-stripe b-animate-go  thick box">
										<img src="images/t9.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
								<li>
									<a href="images/t10.jpg" class="b-link-stripe b-animate-go  thick box">
										<img src="images/t10.jpg" alt="" />
										<div>
											<h5>team</h5>
											<span>non suscipit leo fringilla non suscipit leo fringilla molestie That’s how we set ourselves apart</span>
										</div>
									</a>
								</li>
							</ul>
							<div class="clearfix"> </div>
						</section>
						
					</div>      
				</div>
				<!---team--->
				
				<!---prices--->
				<!---posts--->
					<div class="post-section">
						<div class="container">
							<h3>Facilities</h3>
							<div class="post-grids">
								<div class="col-md-4 post-grid">
									<a class="mask"><img src="new_image/01.png"  class="img-responsive zoom-img" alt="/"></a>
								</div>
								<div class="col-md-4 post-grid">
									<a class="mask"><img src="new_image/02.png" class="img-responsive zoom-img" alt="/"></a>
								</div>
								<div class="col-md-4 post-grid">
									<a class="mask"><img src="new_image/03.png" class="img-responsive zoom-img" alt="/"></a>
									</div>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>
				<!---posts--->
			</div>	
			<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div>
			<!---footer--->
			
			
</body>
</html>