
 <?php  
 //load_data.php  
 //$connect = mysqli_connect("localhost", "root", "", "zzz");  
 $output = '';  
 include('config.php');
 if(isset($_POST["hall_capacity"]))  
 {  
      if($_POST["hall_capacity"] != '')  
      {  
           $sql = "SELECT * FROM hall_details WHERE hall_capacity = '".$_POST["hall_capacity"]."'";  
      }  
      else  
      {  
           $sql = "SELECT * FROM hall_details";  
      }  
      $result = mysql_query($sql);  
      while($row = mysql_fetch_array($result))  
      {  
           $output .= '<div class="col-md-3"><div style="border:1px solid #ccc; padding:20px; margin-bottom:20px;">'.$row["hall_capacity"].'</div></div>';  
      }  
      echo $output;  
 }  
 ?>