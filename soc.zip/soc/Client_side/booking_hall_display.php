

<?php 
include('config.php');

    ?>
	<!--
Au<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Planet Hosting a Hosting Category Flat Bootstrap Responsive Website Template | Login :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 80%;
  
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
		<?php
	include('menu.php');
	
	?>
	<!---hall_capacity select and display hall name--->
		
					<?php
									include('config.php');
									if($_POST['submit']=='next')
									{
										
									$hall_capacity=$_POST['hall_capacity'];
						          	
									
	$sql = "select hall_name from hall_details where hall_capacity='$hall_capacity'";
	$result = mysql_query($sql);
	while($row = mysql_fetch_array($result)){
	
	 $hall_capacity = $row['hall_name'];
	 
	
	 
			}
	
?>
<!---select hall Name And Auto Display Price -->
					<?php
									include('config.php');
									if($_POST['submit']=='next')
									{
										
									$rent_price=$_POST['hall_capacity'];
									//$hall_Capacity=$_POST['hall_Capacity'];
									
									$pur_booking=$_POST['sub2'];
									$booking_date=$_POST['shootdate'];
									
	$sql = "select rent_price from hall_details where hall_capacity='$rent_price'";
	$result = mysql_query($sql);
	while($row = mysql_fetch_array($result)){
	
	 $rent_price = $row['rent_price'];
	 
	 $total_rent=$rent_price;
 
			}
	
?>
<!---select hall Name And Auto Display deposit_amount -->
					<?php
									include('config.php');
									if($_POST['submit']=='next')
									{
										
									$deposit_amount=$_POST['hall_capacity'];
									
									
	$sql = "select deposit_amount from hall_details where hall_capacity='$deposit_amount'";
	$result = mysql_query($sql);
	while($row = mysql_fetch_array($result)){
	

	 
	 $net_amount=$total_rent;
	
	
									}
	
?>

<?php					
									}
									}
									}
									
									?>
		
<table id="customers" align="center">
  <tr>
									<th>Hall Name</th>
									<th>Purpose Of Booking</th>
									<th>Booking date</th>
									<th>Total Hall Rent Amount</th>
								
  </tr>
  
  <tr>
  <td ><?php echo $hall_capacity;?></td>
<td><?php echo $pur_booking;?></td>
<td><?php echo $booking_date; ?></td>
<td><?php echo $total_rent;?></td>

  </tr>

  <tr><td colspan="8" align="right"><h2>Total Amount Pay & Booking Now</h2></td></tr>
  <td colspan="8" align="right"><h1><i class="fa fa-inr"></i> <?php echo number_format($net_amount);?></h1></td>
   

	

	<form class="form-container" action="hall_booking_process.php" method="post>
							
				<div class="content">
					<div class="contact">
						<div class="container">
							
							<div class="col-md-8 contact-left cont">
						
								<form>
								       
												    
							<input type="hidden" name="date" value="<?php
								$test = strtotime($booking_date);
								$dbtest = date('m-d-Y',$test);
								$s = substr($dbtest,0,1);
							// Date Substring 1 to 9 Date 0 Remove logic
								if($s=='0')    
								{
									$dt = substr($dbtest,1);
								}
								else
								{
									$dt = $dbtest;    
								}
								$ss=substr($dt,2,1);
								if($ss=='0'){
								 
								    
								    $fh=substr($dt,0,2);
								    $sh=substr($dt,3,9);
								    
								    $dt=$fh.$sh;
								  
								}
								else if($ss=='-'){
								    
								    $dc=substr($dbtest,0,2);
								    $dda=substr($dbtest,3,2);
								    if($dc=='10' ||$dc=='11'||$dc=='12'){
								        if(($dda>=10 && dda<=30) || ($dda>=10 && dda<=31)){
								           $dt = $dbtest;       
								        }else{
								             $fh=substr($dt,0,3);
								             $sh=substr($dt,4,9);
								    
								             $dt=$fh.$sh;
								       
								        }
								    }else{
								  	    $dt = $dbtest;
								    }
								}
									else if($ss=='1'){
								  	$dt = substr($dbtest,1);
								}
								else if($ss=='2'){
								  	$dt = substr($dbtest,1);
								}
								else if($ss=='3'){
								  	$dt = substr($dbtest,1);
								}
								
							else
								{
								  $fh=substr($dt,0,3);
								  $sh=substr($dt,4,10);
								    
								    $dt=$fh.$sh;
								}
							echo $dt;
							   ?>">  
                
                					<?php
							 $name=$_POST['name'];
							 $email=$_POST['email'];
						
							  $number=$_POST['number'];
						
								
									$_SESSION['nm']=$number;
										$_SESSION['hl']=$hall_capacity;
											$_SESSION['dt']=$dt;
												$_SESSION['pb']=$pur_booking;
    				
    						     
							?>
									
								
					
								
								</div>
<tr><td colspan="8" align="right"><h2><a href="payment_gateway_2/pay.php?total=<?php echo $net_amount;?> &email=<?php echo $email;?> &name=<?php echo $name;?> &number=<?php echo $number;?>&hall_name=<?php echo $hall_capacity;?>&booking_date=<?php echo $dbtest;?>&total_hall_rent=<?php echo $total_rent;?>  &purpose_Of_booking=<?php echo $pur_booking;?>" class="btn btn-success" name="buy" value="submit"> Pay Now </a>
</h2></td></tr>				

								</form>
				
</table>
								
						
									
							<div class="clearfix"> </div>
						</div>
						
					</div>
					
 
	
	
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!-- login -->
				<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div>
				<!---footer--->
</body>
</html>