<!--
Au<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php 
	include('config.php');
	?>
<!DOCTYPE HTML>
<html>
<head>
<title>Planet Hosting a Hosting Category Flat Bootstrap Responsive Website Template | Login :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
</head>
<body>
	<!---header--->
		<?php
	include('menu.php');
	
	?>
<!---header--->
		<!---login--->
			<div class="content">
				<div class="main-1">
					<div class="container">
						<div class="login-page">
							<div class="account_grid">
							<img src="new_image/f.png" height="260" width="350" align="left">
								
								<form class="form-container" action="forgot_password_process.php" method="post">
							
								<div class="col-md-6 login-right">
									<br><br><br><br><br><br><br>
									  <div>
										<span>Enter Mobile Number<label>*</label></span>
										<input type="text" name="mobile" pattern="[1-9]{1}[0-9]{9}" title="Enter 10 digit mobile number" placeholder="Mobile number" required> 
									  </div>
									  <br>
									 
									 <br>
									  
						
							<input class="btn btn-primary" type="submit" name="reg" value="submit">
									
	<h4 style="color:red;">
										<?php 
										  if (isset($_GET['msg'])) echo $_GET['msg'];
											
										?>
										
									
								</div>	
								</form>
								
				
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
<!-- login -->
				<!---footer--->
				<br><br><br><br>
			<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div><!---footer--->
				
</body>
</html>