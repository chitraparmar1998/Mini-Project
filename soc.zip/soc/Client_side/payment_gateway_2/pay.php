<?php
        
$product_name = "Society Hall Booking ";
echo $total = $_GET['total'];
echo $booking_date =  $_GET['booking_date'];
echo $hall_name = $_GET['hall_name'];       
echo $purpose_Of_booking = $_GET['purpose_Of_booking'];   
echo $phone = $_GET['number'];
echo $email = $_GET['email'];

include 'src/instamojo.php';     

//$api = new Instamojo\Instamojo('test_8b2d5d1c688f8e9a722b0721bac', 'test_703034b16178ee2e5a45c0b1815','https://test.instamojo.com/api/1.1/');
$api = new Instamojo\Instamojo('test_92408ba4b8a39f57387ee61797d', 'test_6b3f5dcc59e9529032610ddd61e','https://test.instamojo.com/api/1.1/');


try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => $product_name,
        "amount" => $total,
       "buyer_email" => $email,
       "phone" => $phone,

        "send_email" => true,
      "send_sms" => true,
        "email" => $email,
        'allow_repeated_payments' => false,
        "redirect_url" => "https://balaji-sourcecode.com/jigar/Client_side/payment_gateway_2/thankyou.php",
        "webhook" => "http://balaji-sourcecode.com/jigar/Client_side/payment_gateway_2/webhook.php"
        ));
    print_r($response);

    $pay_ulr = $response['longurl'];
    
    //Redirect($response['longurl'],302); //Go to Payment page

    header("Location: $pay_ulr");
    exit();

}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}    

  ?>