
<?php 
include('config.php');

    ?>

	<!--
Au<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Planet Hosting a Hosting Category Flat Bootstrap Responsive Website Template | Login :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 30%;
  
}

#customers td, #customers th {
  border: 5px solid #ddd;
  padding: 15px;
  
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 15px;
  padding-bottom: 12px;
  text-align: justify;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
	<!---header--->
			<?php
	include('menu.php');
	
	?>

	
		
		<?php
	include('config.php');
	
	$email=$_SESSION['email'];
	if($email)
	{	
		$query=mysql_query("SELECT * FROM member_reg  WHERE email='$email'");

		$row=mysql_fetch_assoc($query);
		
		
		
		?>
<table id="customers" align="center">
  <tr>
									<th colspan="2"><h2> MY ACCOUNT DETAILS	</h2></th>
									
  </tr>

 <tr>
								<th width="70%">Member Name</th>
									<td><?php echo $row['member_name'];?></td>
	
  </tr>
   <tr>
									<th>Email ID</th>
									<td><?php echo $row['email'];?></td>
	
  </tr>
   <tr>
									<th>Password</th>
									<td><?php echo $row['password'];?></td>
	
  </tr>
  <tr>
									<th>Mobile</th>
									<td><?php echo $row['mobile'];?></td>
	
  </tr>
  <tr>
									<th>Total Member</th>
									<td><?php echo $row['total_member'];?></td>
	
  </tr>
   <tr>
									<th>House Type</th>
									<td><?php echo $row['house_type'];?></td>
	
  </tr>
 
  
  
  <tr>
  
  </tr>
  <tr>
  <td colspan="2" align="right"><h2><a href="my_account_edit.php?edit=<?php echo $row['email'];?>" class="btn btn-success" name="edit"> Edit Now </a>
</h2></td></tr>
 

   

</table>
	<?php
	}
	
	?>
	
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!-- login -->
				<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div>
				<!---footer--->
</body>
</html>