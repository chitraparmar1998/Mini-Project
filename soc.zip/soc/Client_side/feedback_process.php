
<?php include('config.php');

if($_POST['reg']=='submit')
	{  
	$name=$_POST['name'];
	$email =$_POST['email'];
	$mobile=$_POST['number'];
	$msg=$_POST['msg'];
	
	


	$sql="INSERT INTO feedback(name,email,mobile_no,msg)VALUES('$name','$email','$mobile','$msg')";
	$result = mysql_query($sql);
	echo $sql;
 if($result)
	{
  

		$msg="Thank You Your Feedback";
		header("location:feedback.php?msg=".$msg);
	
} 
    else
    {
		$msg="Sorry..............";
    header("location:feedback.php?msg=".$msg);
	
			
    }
	}
		
    
	
?>