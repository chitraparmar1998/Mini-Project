<?php $link=mysql_connect("localhost","root","");
	$db=mysql_select_db("society",$link);
	@session_start();
	if($db)


/*
echo " sucessfull connect DB";

else
{
echo "Error";	
}*/




?>