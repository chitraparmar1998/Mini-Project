<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php 
	include('config.php');
	?>
<!DOCTYPE HTML>
<html>
<head>
<title>Planet Hosting a Hosting Category Flat Bootstrap Responsive Website Template | Prices :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
</head>
<body>
		<?php
	include('menu.php');
	
	?>

	<!---header--->
		<!---prices--->
				<div class="content">
					<div class="detailed-section">
						<div class="container">
						
						
						
							<h2>Available Facilities</h2>
							<div class="detailed-grids">
								<div class="col-md-3 detailed-grid">
									<div class="detailed-top">
										<h4>Club House</h4>
									</div>
									<div class="detailed-bottom">
										<h5>Open 9:00 <span>A/M</span></h5>
										<ul>
										<li><img src="new_image/club.jpg" width="250" height="200"></li>
										<li>Get More Deatils</li>
										</ul>
										<a href="club_singal.php" class="button1">More Deatils</a>
									</div>
								</div>
								<div class="col-md-3 detailed-grid">
									<div class="detailed-top">
										<h4>Swimming Pool</h4>
									</div>
									<div class="detailed-bottom">
										<h5>Open 9:00 <span>A/M</span></h5>
										<ul>
										<li><img src="new_image/pool.jpg" width="250" height="200"></li>
										<li>Get More Deatils</li>
										</ul>
										<a href="swimming_singal.php" class="button1">More Details</a>
									</div>
								</div>
								<div class="col-md-3 detailed-grid">
									<div class="detailed-top">
										<h4>GYM</h4>
									</div>
									<div class="detailed-bottom">
										<h5>Open 9:00 <span>A/M</span></h5>
										<ul>
										    
										<li><img src="new_image/gym.webp" width="250" height="200"></li>
									<li>Get More Deatils</li>
										
										</ul>
										<a href="gym_singal.php" class="button1">More Details</a>
									</div>
								</div>
								<div class="col-md-3 detailed-grid">
									<div class="detailed-top">
										<h4>Hall </h4>
									</div>
									<div class="detailed-bottom">
										<h5>Open 9:00 <span>A/M</span></h5>
										<ul>
										<li><img src="new_image/hall.jpg" width="250" height="200"></li>
										<li>More Details Go To Booking Now</li>
										</ul>
										<a href="hall_booking.php" class="button1">Booking Now </a>
									</div>
								</div>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>
					<!---prices--->
				</div>
			<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div><!---footer--->
			
			
</body>
</html>