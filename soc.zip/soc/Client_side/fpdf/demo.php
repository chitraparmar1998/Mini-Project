<?php 
require "fpdf.php";

require "config.php";


//$db = new PDO('mysql:host=localhost;dbname=society','root','');
$db = new PDO('mysql:host=localhost;dbname=society','root','');

class myPDF extends FPDF{
    function header(){
		
        $this->SetFont('Arial','B',25);
		$this->SetFillColor(192,192,192);
		
		$this->SetTextColor(10);
		$this->Cell(0,20,'SMART SOCIETY',0,1,'C',true);
		$this->Ln(2);
		 
		 $this->SetFont('Arial','B',15);
		 $this->Cell(276,7,'Society Notice',0,0,'C');
		
  }
		function footer(){
        $this->SetY(-15);
        $this->SetFont('Arial','',8);
        $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
	
    function headerTable(){
     	$this->SetFont('Times','B',12);
		
		
		$this->Ln();
    }
	
    function viewTable($db){
	
        $this->SetFont('Times','',12);
		$notice_id = $_GET['edit'];
		
		$email=$_SESSION['email'];
		$query ="SELECT * FROM notice notice where notice_id = '$notice_id'";

			$result=mysql_query($query);
			while($row=mysql_fetch_array($result)){ 
				
			
			$this->SetY(40);
			$this->Cell(10,10, "Notice ID :-  ",0,0);
			$this->SetX(45);
			$this->Cell(10,5,'',0,0);
			$this->Cell(0,10,$row['notice_id'],0,1);
	
			$this->SetY(50);
			$this->Cell(20,10, "Subject :-  ",0,0);
			$this->SetX(45);
			$this->Cell(10,5,'',0,0);
			$this->Cell(0,10,$row['notice_subject'],0,1);
	
			$this->SetY(60);
			$this->Cell(20,10, "Notice Sending Date  :-  ",0,0);
			$this->SetX(45);
			$this->Cell(10,5,'',0,0);
			$this->Cell(0,10,$row['date'],0,1);
			
			$this->SetY(70);
			$this->Cell(20,10, "Member ID  :-  ",0,0);
			$this->SetX(45);
			$this->Cell(10,5,'',0,0);
			$this->Cell(0,10,$email,0,1);
			
			$this->SetY(80);
			$this->Cell(20,10, "Dear _____________  ",0,0);
	
$current_y = $this->SetY(90);
$current_x = $this->SetX(50);
$cell_width = 200;  //define cell width
$cell_height=7;    //define cell height

$this->MultiCell($cell_width,$cell_height,$row['notice_con'],0); //print one cell value
	

$current_y = $this->SetY(140);
$current_x = $this->SetX(35);

$this->Cell(15,8, "Notes:- ",0,0);	
$cell_width = 200;  //define cell width
$cell_height=7;    //define cell height
$this->MultiCell($cell_width,$cell_height,$row['notes'],0); //print one cell value
		

$this->SetFont('Arial','B',13);	
$current_y = $this->SetY(165);
$current_x = $this->SetX(200);
$this->Cell(15,6, "O/B :",0,0);	
$cell_width = 40;  //define cell width
$cell_height=5;    //define cell height

$this->Cell($cell_width,$cell_height,$row['notice_sender_name'],0);


		 }
		 }
	}
	

$pdf = new myPDF();
$pdf->AliasNbPages();
$pdf->AddPage('L','A4',0);
$pdf->headerTable();
$pdf->viewTable($db);
$pdf->Output();