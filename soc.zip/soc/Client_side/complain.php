		<?php

include('config.php');					
					if(isset($_SESSION['email'])){?>
									<?php
					}
					else 
					{
					header("Location: admin_login.php");

					}
					?>	
			
	<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php 
	include('config.php');
	?>
<!DOCTYPE HTML>
<html>
<head>
<title>Complaint</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
</head>
<body>
	<!---header--->
	<?php
	include('menu.php');
	
	?>
	<!---header--->
		<!-- //contact -->
		<?php
	include('config.php');
	
	$email=$_SESSION['email'];
	if($email)
	{	
		$query=mysql_query("SELECT * FROM member_reg  WHERE email='$email'");

		$row=mysql_fetch_assoc($query);
		
		
		
		?>
		<form class="form-container" action="complain_process.php" method="post">
							
				<div class="content">
					<div class="contact">
						<div class="container">
							<h2>Complaint</h2>
							
							<div class="col-md-4 contact-left">
								<h4>Office Address</h4>
								<p>est eligendi optio cumque nihil impedit quo minus id quod maxime
									<span>26 56D Rescue,US</span>
								<ul>
									<li>Free Phone :+1 078 4589 2456</li>
									<li>Telephone :+1 078 4589 2456</li>
									<li>Fax :+1 078 4589 2456</li>
									<li><a href="mailto:info@example.com">info@example.com</a></li>
								</ul>
							</div>
							
							<div class="col-md-8 contact-left cont">
								
								<form>
									<input type="hidden" value="<?php echo $row['member_name'];?>" name="name" placeholder="Name"   required="">
									<input type="hidden"  value="<?php echo $row['email'];?>" name="email" placeholder="Email" required="">
									<input type="hidden" value="<?php echo $row['mobile'];?>" name="number" placeholder="Telephone"  required="">
									<input  type = "hidden" name="date" value="<?php echo date("d/m/Y");?>" />
									<textarea type="text" name="msg" placeholder="Message" required=""> </textarea>
									<input type="submit" name=" reg" value="submit" >
									<input type="reset" value="Clear" >

								</form>
								
							</div>
							<div class="clearfix"> </div>
							<?php
							}
							?>
						</div>
					</div>
					</form>
<!-- //contact -->

				</div>
			<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div><!---footer--->
			
			
</body>
</html>