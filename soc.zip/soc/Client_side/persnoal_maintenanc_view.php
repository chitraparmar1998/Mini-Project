
<?php 
include('config.php');

    ?>
	<?php 
include('config.php');
if(isset($_GET['view'])){
 $month = $_GET['view'];
$type= $_GET['house_type'];
 $member_name= $_GET['member_name'];
  $email=$_GET['email'];
 $mobile=$_GET['mobile'];
	
	

$query ="SELECT * FROM maintenance_charges where month = '$month' and house_type='$type'";



$result=mysql_query($query);
while($row=mysql_fetch_array($result)){
   
    ?> 
	<!--
Au<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Planet Hosting a Hosting Category Flat Bootstrap Responsive Website Template | Login :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 30%;
  
}

#customers td, #customers th {
  border: 5px solid #ddd;
  padding: 15px;
  
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 15px;
  padding-bottom: 12px;
  text-align: justify;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
	<!---header--->
			<?php
	include('menu.php');
	
	?>

<table id="customers" align="center">
  <tr>
									<th colspan="2"><?php echo $month;?> Maintenanc Charges</th>
									
  </tr>

 <tr>
									<th width="70%">Maintenanc Charges</th>
									<td><?php echo $row['m_charges'];?></td>
	
  </tr>
   <tr>
									<th>Parking Charges</th>
									<td><?php echo $row['parking_charges'];?></td>
	
  </tr>
   <tr>
									<th>GYM Charges</th>
									<td><?php echo $row['gym_charges'];?></td>
	
  </tr>
  <?php 
  	$m_charges = $row['m_charges'];   
	 $p_charges = $row['parking_charges'];
	 $gym_charges = $row['gym_charges'];
	$total=$m_charges+$p_charges+$gym_charges;    
	
	 $email=$_SESSION['email'];
	 $mobile=$_SESSION['mobile'];
	 $house_type=$_SESSION['house_type'];
		
	
  ?>
  
  
  <tr>
  <td><h1>Total Amount</h1></td>
  <td><h1><?php echo  number_format($total);?></h1></td>
  
  </tr>
  <tr>
<td></td>


<?php 
$query=mysql_query("SELECT * FROM pay_maintenance  WHERE email='$email' and pdate='$month'");

$row=mysql_fetch_assoc($query);

$pdate = $row['pdate'];
//echo $month;

if ($month == $pdate){
?>
<td><h2><class="btn btn-success" name="buy" disabled> Paid </a></h2></td>

<?php
}
else  {    
?>
  <td><h2><a href="payment_gateway/pay.php?total=<?php echo $total;?>&name=<?php echo $member_name;?>&email=<?php echo $email;?> &mobile=<?php echo $mobile;?> &house_type=<?php echo $type;?> &month=<?php echo $month;?> " class="btn btn-success" name="buy"> Pay Now </a></h2></td>

<?php
}?>
  </tr>
 

        

</table>
<?php
								}
								}
								
								?>
	
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!-- login -->
				<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div>
				<!---footer--->
</body>
</html>