<?php

$product_name = "Society Maintenance Pay ";
$total = $_GET['total'];
$member_name =  $_GET['member_name'];
$phone = $_GET['mobile'];
$email = $_GET['email'];
$house_type = $_GET['house_type'];   
$month=$_GET['month'];


include 'src/instamojo.php';

//$api = new Instamojo\Instamojo('test_8b2d5d1c688f8e9a722b0721bac', 'test_703034b16178ee2e5a45c0b1815','https://test.instamojo.com/api/1.1/');
$api = new Instamojo\Instamojo('test_92408ba4b8a39f57387ee61797d', 'test_6b3f5dcc59e9529032610ddd61e','https://test.instamojo.com/api/1.1/');


try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => $month,
        "amount" => $total,
       "buyer_email" => $member_name,
       "phone" => $phone,

        "send_email" => true,
      "send_sms" => true,
        "email" => $email,
        'allow_repeated_payments' => false,
        "redirect_url" => "https://balaji-sourcecode.com/jigar/Client_side/payment_gateway/thankyou.php",
        "webhook" => "http://balaji-sourcecode.com/jigar/Client_side/payment_gateway/webhook.php"
        ));
    print_r($response);

    $pay_ulr = $response['longurl'];
    
    //Redirect($response['longurl'],302); //Go to Payment page

    header("Location: $pay_ulr");
    exit();

}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}    

  ?>