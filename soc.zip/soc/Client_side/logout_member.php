
<?php
session_start();
unset($_SESSION['email']);
session_destroy();

header("Location: login_member.php");
exit;

?>