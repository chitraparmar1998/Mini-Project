
<?php include('config.php');

if($_POST['reg']=='submit')
	{  
		//$test = strtotime($dbvar);
	//	$dbtest = date('m-d-Y',$test);
	
	//$hall_name=$_POST['name'];
	$date=$_POST['date'];
	


	$sql="INSERT INTO booking(date)VALUES('$date')";
	$result = mysql_query($sql);
	echo $sql;
 if($result)
	{
  

	//	$msg="Successfully FeedBack...";
		header("location:hall_booking.php?msg=".$msg);
	
} 
    else
    {
		//$msg="Sorry..............";
	///	header("location:feedback.php?msg=".$msg);
	
			
    }
	}
		
    
	
?>