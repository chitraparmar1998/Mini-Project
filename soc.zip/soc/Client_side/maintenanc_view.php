

<?php 
include('config.php');

    ?>
	<!--
Au<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Maintenance View</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 80%;
  
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
	<!---header--->
	<?php
	include('menu.php');
	
	?>

	

							<h1 align ="center" font style="arial"><b>Maintenance </b></h1><br>
						
<table id="customers" align="center" width="50%">
  <tr>
									<th width="10%">House Type</th>     
									<th width="10%">Name</th>
									
									
									
  </tr>
  			
  
<?php
	
$email=$_SESSION['email'];
	if($email)
	{	
		$query=mysql_query("SELECT * FROM member_reg  WHERE email='$email'");

		$row=mysql_fetch_assoc($query);
		$house_type=$row['house_type'];
	 $member_name= $row['member_name'];
	 $mobile= $row['mobile'];
	  
		?>
		<tr>
	
	<td><?php echo $row['house_type'];?></td>
<td ><?php echo $row['member_name'];?></td>

	</tr>

<!-- House Type To Find All Charges..Ret...-->
  <?php
		$month[] = "";
		
	$sql = "select m_charges,parking_charges, gym_charges, month,house_type from maintenance_charges where house_type='$house_type'";
	$result = mysql_query($sql);
	while($row = mysql_fetch_array($result)){     
	
	 
	  $month = $row['month'];
	 $_SESSION['mnth']=$row['month'];
	  $house_type = $row['house_type'];

	
	 
	
?>

<tr  ><td  colspan="4" align="center"><?php echo '</br>',$row['month'];?></td>



<td colspan="3" align="left"><a href="persnoal_maintenanc_view.php?view=<?php echo $row['month'];?>&house_type=<?php echo $row['house_type'];?> &member_name=<?php echo $member_name;?> &email=<?php echo $email;?> &mobile=<?php echo $mobile;?>" >Click & View</td></tr>

    

	 

	
	<?php
	}				
	}
	
	
					?>		
			
</table>
	
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!-- login -->
				<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div>
				<!---footer--->
</body>
</html>