<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php 
	include('config.php');
	?>
<!DOCTYPE HTML>
<html>
<head>
<title>Planet Hosting a Hosting Category Flat Bootstrap Responsive Website Template | Windows Hosting :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
</head>
<body>
	<!---header--->
	<?php
	include('menu.php');
	
	?>
	<!---header--->
		<!---singleblog--->
				<div class="content">
					<div class="linux-section">
						<div class="container">
							<div class="linux-grids">
								<div class="col-md-8 linux-grid">
								<h2>GYM</h2>
								<ul>
									<li>This facility is Only Available For Society Member</li>
									<li><span>Open Time </span>  06:00AM To 10:00AM &  05:00PM To 07:00PM </li>
									<li><span>The</span> Haynes Landing Clubhouse is the centerpiece of this lovely Johns Creek community.  The main level has a spacious great room and kitchen area, perfect for any social event or meeting. An expansive deck overlooks surrounding trees and tennis courts.  The main level also connects directly to the neighborhood pool.  A lower level room is suitable for exercise classes and kid friendly events. Clubhouse usage is exclusive to Haynes Landing residents in good standing only. </li>
								</ul>
									<!--<a href="#">view plans</a>-->
								</div>
								<div class="col-md-4 linux-grid1">
									<img src="new_image/gym.webp" height="300" width="450" alt=""/>
								</div>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>
					<!-- clients -->
				
       <!-- clients -->
			

				</div>
				<br><br>
			<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div>
				<!---footer--->
			
			
</body>
</html>