
<?php include('config.php');

if($_POST['reg']=='submit')
	
	  $mobile= $_POST["mobile"];
		
		$query=mysql_query("SELECT * FROM member_reg  WHERE mobile='$mobile'");

		$row=mysql_fetch_assoc($query);
		
		$password=$row['password'];
		$name=$row['member_name'];
	
		
    $fields = array(
    "sender_id" => "FSTSMS",
    "message" => "$name.  Your Password is $password",
    "language" => "english",
    "route" => "p",
    "numbers" => "$mobile",
    "flash" => "0"
);
	
		
		
	
	
$curl = curl_init();

	
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.fast2sms.com/dev/bulk",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($fields),
  CURLOPT_HTTPHEADER => array(
    "authorization: qLORQhevX7Hj1ZzCfsYciBxN2k0tFUVab8lmI5gr3KAMnpE9DysiUZb56Q2jIPGxTvSAekcOK07hBdty",
    "accept: */*",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));	
		
		
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  //echo "cURL Error #:" . $err;
  
		$msg="Successfully Send Password Your Phone..";
		header("location:forgot_password.php?msg=".$msg);
  
  
} else {

  //echo $response;
  $msg="Your Password has been Send successfully! ";
		
  header("location:forgot_password.php?msg=".$msg);
  
}

	
	
	
?>
