
<?php include('config.php');

if($_POST['reg']=='submit')
	{  
	$m_name=$_POST['m_charges'];
	$house_type=$_POST['house_type'];
	$p_charges=$_POST['p_charges'];
	$g_charges=$_POST['g_charges'];
	
	$month=$_POST['month'];
	
	//echo $month;
	$month= strtotime($month);
	$month= date('d-m-y',$month);
	
	
	
	

	$sql="INSERT INTO maintenance_charges(m_charges,house_type,parking_charges,gym_charges,month)
	VALUES('$m_name','$house_type','$p_charges','$g_charges','$month')";
	$result = mysql_query($sql);
	echo $sql;
 if($result)
	{
  

		$msg="Successfully Add Charges..";
		header("location:maintenanc_charges.php?msg=".$msg);
	
} 
    else
    {
			//$msg="You ve already Charges..";
		//	header("location:maintenanc_charges.php?msg=".$msg);
	
			
    }
	}
	
    
	
?>