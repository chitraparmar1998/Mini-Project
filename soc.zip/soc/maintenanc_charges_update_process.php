<?php
// edit data update 
if (isset($_POST['update']))
{

include ('config.php');
	
	$m_id=$_POST['m_id'];
	$m_charges=$_POST['m_charges'];
	$house_type=$_POST['house_type'];
	$parking_charges=$_POST['p_charges'];
	$gym_charges=$_POST['g_charges'];
	$month=$_POST['month'];
	
	$month=$_POST['month'];
	
	//echo $month;
	$month= strtotime($month);
	$month= date('d-m-y',$month);
	
	
	
$sql="UPDATE maintenance_charges SET m_charges='$m_charges',house_type='$house_type',parking_charges='$parking_charges',gym_charges='$gym_charges',month='$month' WHERE m_id='$m_id'";
	 
		echo $sql;
	
	$result=mysql_query($sql);	
	if ($result)
	{
		header("location:maintenanc_charges.php?Successfully Update..");
	}
	else 
	{
		echo "<script>alert('Sorry You already Update Data')</script>";
	
	}
	}
	?>

