<?php

include('config.php');					
					if(isset($_SESSION['email'])){?>
									<?php
					}
					else 
					{
					header("Location: admin_login.php");

					}
					?>	
<?php
include('config.php');
//delete data in tabal

if (isset($_GET['delete'])){
$staff_id = $_GET['delete'];

mysql_query("DELETE FROM staff WHERE staff_id= '$staff_id'");

header("location:staff.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/admin_panel.css" rel="stylesheet">
	<style>
.dropbtn {
  background-color: #222;
  color: white;
  padding: 16px;
  font-size: 14px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>

    <title>Staff Add</title>
  </head>

  <body>


    <?php
	include('menu.php');
	
	?>

	<header id="header">
		<div class="container">
			<div class="row">
				<div class="col-md-10">
					<h1><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>  Staff Add</small></h1>
				</div>
			</div>
		</div>
	</header>
	
	<section id="breadcrumb">
		<div class="container">
			<ol class="breadcrumb">
				<li>Admin Panel</li>
				<li class="active">Staff Add</li>
		</ol>
		</div>
	</section>
	


	<section id="main">
		<div class="container">
			<div class="row">
				<div class="col-md-12"><!-- website overview -->
					<div class="panel panel-default">
					  <div class="panel-heading main-color-bg">
						<h3 class="panel-title">Staff Add</h3>
					 </div>
					</div>
					<!-- latest user -->
					<div class="panel panel-default">
					  <div class="panel-body">
						<div class="table-responsive">
						<form action="staff_process.php" method="post" enctype="multipart/form-data">
							<div class="rows">
								
								
								
									<div class="form-group text-left col-md-6">
										<label>Staff Name :</label>
										<input class="form-control" type="text" name="staff_name" required>
									</div>
									
									<div class="form-group text-left col-md-6">
										<label>Designation :</label>
										<input class="form-control" type="text" name="Designation" required>
									</div>
									<div class="form-group text-left col-md-6">
										<label>Email :</label>
										<input class="form-control" type="text" name="femail" required>
									</div>
									
								
									<div class="form-group text-left col-md-6">
										<label>Mobile No :</label>
										<input class="form-control" type="text" name="mobile" required>
									</div>
										<div class="form col-md-6">
										<label>Gender :</label>&nbsp&nbsp&nbsp
										Male&nbsp&nbsp&nbsp <input class="control"  value="male"  type="radio" name="gender" required>&nbsp&nbsp&nbsp
										Female&nbsp&nbsp&nbsp <input class="control"  value="female"  type="radio" name="gender" required>
														
										</div>
								
	

									<br><br><br><br>
									<div class="form-group text-left col-md-4">
										<input class="btn btn-primary" type="submit" name="reg" value="submit">
									<!--MSG PASS-------->
										<h4 style="color:red;">
										<?php 
										  if (isset($_GET['msg'])) echo $_GET['msg'];
											
										?>
										
											</h4>							
								
									</div>
								</div>
							</form>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	
	<section id="main">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12"><!-- website overview -->
					<div class="panel panel-default">
					  <div class="panel-heading main-color-bg">
						<h3 class="panel-title">Staff Deatails</h3>
					 </div>
					</div>
					<!-- latest user -->
						

										<div style="width:1300;height:500px;line-height:3em;overflow:scroll;padding:5px;">

					<div class="panel panel-default">
					  <div class="panel-body">
						<div class="table-responsive">
							<table  class="table table-striped table-hover">
									<tr>
									<th>Staff ID</th>
									<th>Staff Name</th>
									<th>Designation </th>
									<th>Email</th>
									<th>Mobile No</th>
									<th>Gender</th>
									<th>Delete</th>
									<th>Update</th>
									
									</tr>
			<?php 
				include('config.php');

				$query ="SELECT * FROM staff";

				$result=mysql_query($query);

				while($row=mysql_fetch_array($result)){
   
    ?>   
								
								<tr>
								<td><?php echo $row['staff_id'];?></td>
								<td><?php echo $row['staff_name'];?></td>
								<td><?php echo $row['designation'];?></td>
								<td><?php echo $row['email'];?></td>
								<td><?php echo $row['mobile_no'];?></td>
								<td><?php echo $row['gender'];?></td>
								
	<td>										
	<a href="staff.php?delete=<?php echo $row['staff_id'];?>"  onclick="return confirm('Are You Sure Delete Product?');">

		<i class="glyphicon glyphicon-trash" style="font-size:25px" aria-hidden="true"></i>
		<div class="clearfix"></div>

	</a>
	</td>
	<td>
	<a href="staff_update.php?edit=<?php echo $row['staff_id'];?>"  onclick="return confirm('Are You Sure Edit Product?');">
	
	<i class="glyphicon glyphicon-edit" style="font-size:25px"aria-hidden="true"></i>
	<div class="clearfix"></div>
	
</a>
	</td>	
	</tr>

	<?php
		}
		
		
	?>

							</table>
							
						</div>
					</div>
					</div>
				</div>
			</div>
		</div>
	</section>	
	
	<!-- Modal -->
		<div class="modal fade" id="addpage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form>
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Page</h4>
				  </div>
				  <div class="modal-body">
					...
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary">Save changes</button>
				  </div>
				 </form> 
			</div>
		  </div>
		</div>
	<!-- footer -->
	
	
  </body>
</html>
