
<?php include('config.php');

if($_POST['reg']=='submit')
	
	
	
	
	{  
	$m_name=$_POST['m_name'];
	$email=$_POST['m_email'];
	$address=$_POST['address'];
	$password=$_POST['password'];
	$total_member=$_POST['total_member'];
	$gender=$_POST['gender'];
	$house_type=$_POST['house_type'];
	$mobile=$_POST['mobile'];

	
	

	$sql="INSERT INTO member_reg(member_name,email,address,password,total_member,gender,house_type,mobile)VALUES('$m_name','$email','$address','$password','$total_member','$gender','$house_type','$mobile')";
	$result = mysql_query($sql);
	echo $sql;
 if($result)
	{
	     $name= $_POST["m_name"];
	
	 $mobile= $_POST["mobile"];
	 $m_email= $_POST["m_email"];
	 
	 $password= $_POST["password"];
	 
	
    $fields = array(
    "sender_id" => "FSTSMS",
    "message" => "$name  .Your User id is $m_email.& Your Password is $password Visit Website www.Socity.com",
    "language" => "english",
    "route" => "p",
    "numbers" => "$mobile",    
    "flash" => "0"
);
		
$curl = curl_init();

	
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.fast2sms.com/dev/bulk",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($fields),
  CURLOPT_HTTPHEADER => array(
    "authorization: qLORQhevX7Hj1ZzCfsYciBxN2k0tFUVab8lmI5gr3KAMnpE9DysiUZb56Q2jIPGxTvSAekcOK07hBdty",
    "accept: */*",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));	
		
		
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}

  

		$msg="Successfully Registration Member...";
		header("location:member_reg.php?msg=".$msg);
	
} 
    else
    {
		$msg="You ve already Registration..";
		header("location:member_reg.php?msg=".$msg);
	
			
    }
	}
	
?>
