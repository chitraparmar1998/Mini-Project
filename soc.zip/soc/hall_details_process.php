
<?php include('config.php');

if($_POST['add']=='submit')
	{  
	$hall_name=$_POST['hall_name'];
	$hall_type=$_POST['hall_type'];
	$des=$_POST['des'];	
	$hall_capacity=$_POST['hall_capacity'];
	$rent_price=$_POST['rent_price'];
	$deposit_amount=$_POST['deposit_amount'];
	

	
	$sql="INSERT INTO hall_details(hall_name,hall_type,des,hall_capacity,rent_price,deposit_amount)VALUES('$hall_name','$hall_type','$des','$hall_capacity','$rent_price','$deposit_amount')";
	$result = mysql_query($sql);
 echo $sql;
 if($result)
	{
  

		$msg="You Successfully Add Hall...";
		header("location:hall_details.php?msg=".$msg);
	
} 
    else
    {
	//	$msg="You ve already Add Hall...";
		//header("location:hall_details.php?msg=".$msg);
	
			
    }
	}
		
    
	
?>