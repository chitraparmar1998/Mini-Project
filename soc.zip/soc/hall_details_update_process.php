<?php
// edit data update 
if (isset($_POST['update']))
{

include ('config.php');

$hall_id=$_POST['hall_id'];
	
	$hall_name=$_POST['hall_name'];
	$hall_type=$_POST['hall_type'];
	$des=$_POST['des'];	
	$hall_capacity=$_POST['hall_capacity'];
	$rent_price=$_POST['rent_price'];
	$deposit_amount=$_POST['deposit_amount'];
	

	$sql="UPDATE hall_details SET hall_name='$hall_name',hall_type='$hall_type',des='$des',hall_capacity='$hall_capacity',rent_price='$rent_price',deposit_amount='$deposit_amount' WHERE hall_id='$hall_id'";

	echo $sql;
	
	$result=mysql_query($sql);
	if ($result)
	{
		
		header("location:hall_details.php?Successfully Update..");
	}
	else 
	{
		echo "<script>alert('Sorry You already Update Data')</script>";
	
	}
	}
	?>

