

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=1.0">
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="css/admin_panel.css" rel="stylesheet">
	</head>
		<header id="header">
		<div class="container">
			<div class="row">
				<div class="col-md-10">
					<h1><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>  Admin Login</h1>
				</div>
			</div>     
		</div>
	</header>    
	
	<body style="background-image:	url(image/c4.jpg);";>
	
			<div class="container-fluid bg">
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-12"></div>
						<div class="col-md-4 col-sm-4 col-xs-12">
						<!-- form start -->
						
						<form class="form-container" action="admin_login_process.php" method="post">
							
							<div class="form-group">
								<label for="exampleInputEmail1"  style="color:white;">User Name </label>
								<input type="text" class="form-control" name="femail"  placeholder="User Name" required>
							</div>
							<div class="form-group">
								<label for="exampleInputPassword1"  style="color:white;">Password</label>
								<input type="password" class="form-control"name="fpass"  placeholder="Password" required>
							</div>
						  <input type="submit" name="submit" value="Login" class="btn btn-default">
								<h4 style="color:red;">
										<?php 
										  if (isset($_GET['msg'])) echo $_GET['msg'];
											
										?>	
											</h4>	
						</form>
						<!-- form end -->
						</div>
					
				</div>
			</div>
			
			<script src="js/bootstrap.js" type="text/javascript"></script>
			<script src="js/jquery.min.js" type="text/javaquery"></script>
			
		</body>
</html>