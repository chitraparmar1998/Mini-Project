
    <nav class="navbar navbar-inverse">
		<div class="container">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>     
			  </button>
			  <a class="navbar-brand" href="index.php">Admin Panel</a>	</div>
			<div id="navbar" class="collapse navbar-collapse">
					      
			  <ul class="nav navbar-nav">
						
				<li><a href="member_reg.php">Member Registration</a></li>
				
				<li><a href="member_show.php">Member Details</a></li>
				<li><a href="gallery_add.php">Gallery Photos Add</a></li>
			
				<div class="dropdown">     
				
				
				<button class="dropbtn"style="color:#9d9d9d;">Maintenance Manage</button>
					  <div class="dropdown-content">
						<a href="maintenanc_charges.php">Maintenance Add</a>
						<a href="notice_send.php">Notice Send </a>
						<a href="staff.php">Staff Add </a>
					  </div>
					</div>
						<li><a href="feedback_view.php">Feed Back View </a></li>    
			
					 <div class="dropdown">
				
				
				<button class="dropbtn"style="color:#9d9d9d;">Hall Booking Manage</button>
					  <div class="dropdown-content">
						<a href="booking_hall_details.php">Book Hall Details</a>
						<a href="hall_details.php">Hall Charges Add</a>
						<a href="complain_show.php">Complain Show</a>
					  
					  
					  </div>
					</div>
					 
					
			  	
			  </ul>
				<ul class="nav navbar-nav navbar-right">
				<li><a href="admin_logout.php">Logout</a></li>
				
						
			  </ul>
			</div>
			
			<!--/.nav-collapse -->
		</div>
    </nav>
	