<!--
Au<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<?php 
									include('config.php');
									function fill_brand($mysql) 
									{
								$output = '';  
								$mysql = "SELECT * FROM hall_details"; 								
								$result = mysql_query($mysql);
								//echo"<select  name ='hall_name'>";
								while ($row = mysql_fetch_array($result)) 
								{
								//$output ."<option value='" . $row['hall_name'] ."'>".$row['hall_name']." </option>";
								$output .= '<option value="'.$row["hall_capacity"].'">'.$row["hall_name"].'</option>';  	
								}
								  return $output; 
								}
	

	function fill_product($mysql)  
 {  
      $output = '';  
      $mysql = "SELECT * FROM hall_details";  
      $result = mysql_query( $mysql);  
      while($row = mysql_fetch_array($result))  
      /*{  
           $output .= '<div class="col-md-3">';  
           $output .= '<div style="border:1px solid #ccc; padding:20px; margin-bottom:20px;">'.$row["hall_capacity"].'';  
           $output .=     '</div>';  
           $output .=     '</div>';  
      }  */
      return $output;  
 }  
	
?> 
								
							
<html>
<head>
<title>Planet Hosting a Hosting Category Flat Bootstrap Responsive Website Template | Login :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Planet Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<!---fonts-->
<link href='//fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!---fonts-->
<!--script-->
<link rel="stylesheet" href="css/swipebox.css">
			<script src="js/jquery.swipebox.min.js"></script> 
			    <script type="text/javascript">
					jQuery(function($) {
						$(".swipebox").swipebox();
					});
				</script>
<!--script-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	  	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	  	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<body>
	<!---header--->
	
	<!-- Get DB Date --->
	
			<?php
			
	include('menu.php');
	
	//$test = strtotime($dbvar);
	//$dbtest = date('m-d-Y',$test);
			{
						$query ="SELECT * from booking";
				
						$result=mysql_query($query);
						while($row=mysql_fetch_array($result)){
   
				$date1[] = ($row['date']);
			}	
    	}
		?>
		
		<?php
		for($i=0;$i<sizeof($date1);$i++){
		$dt[] = $date1[$i];	
		}
		
	?>
<!---header--->
		<!---login--->
			<div class="content">
				<div class="main-1">
					<div class="container">
						<div class="login-page"><img src="new_image/hall2.jpg" height="340" width="550" align="left">
									
							<div class="account_grid">
								

									<div class="col-md-6 login-right">
										<h3>Hall Booking</h3>
								
										
							<form  action="booking_hall_display.php"  method="post" enctype="multipart/form-data" >
										
									<h4>	<span >Select Hall Name</span></h4>
									
									<select id="hall_name" select class='form-control' name="hall_capacity"required>  
										<option value="" ><h4>Select Hall Name</h4></option>  
												
												<?php echo fill_brand($mysql); 
												
												?>  
												
									</select>  
									
										
										
										  <div><br>
										<span><h4>Hall Capacity </h4></span>
										  <div class="row" id="show_product" >  
											
										</div> 
										  </div>
									  
									  
										<span><h4>Purpose Of Booking </h4></span>
									
										<?php 
								include('config.php');

								$mysql = "SELECT hall_type FROM hall_details";									
								$result = mysql_query($mysql);
								echo"<select class='form-control'  name ='sub2'>";
								while ($row = mysql_fetch_array($result)) 
								{
								echo "<option value='" . $row['hall_type'] ."'>".$row['hall_type']."</option>";
									
								}
								echo "</select>";
								
								?> 
										<br>
									    <div>
										<span><h4>Select Booking Date</h4></span>
										<input type="text" id="shootdate" name="shootdate" required placeholder="Select Date"/> 
										
										</div>
										 
										
									
									  <br>
									 
										  <input type="submit" value="next" name="submit">
									</form>
								</div>	
								</form>
								
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			
<!-- login -->

				<!---footer--->
				<div class="footer-section">
					<div class="container">
						
						<div class="copy-section">
							<p>&copy; 2019 SK Infosoft. All rights reserved | Design by SK Infosoft</p>
						</div>
					</div>
				</div>
				<!---footer--->
</body>
</html>
<!-- Select Hall Name And Display Hall Capecity-->
<script>  
 $(document).ready(function(){  
      $('#hall_name').change(function(){  
           var hall_capacity = $(this).val();  
           $.ajax({  
                url:"load_data.php",  
                method:"POST",  
                data:{hall_capacity:hall_capacity},  
                success:function(data){  
                     $('#show_product').html(data);  
                }  
           });  
      })
	  		  
 });  
 </script>  


 <script>

	  		/* create an array of days which need to be disabled */
var disabledDays = <?php echo json_encode($dt); ?>;
//alert(disabledDays[0]);

/* utility functions */
function nationalDays(date) {
	var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
	//alert(m);
	//console.log('Checking (raw): ' + m + '-' + d + '-' + y);
	for (i = 0; i < disabledDays.length; i++) {
		if($.inArray((m+1) + '-' + d + '-' + y,disabledDays) != -1 || new Date() > date) {
			//console.log('bad:  ' + (m+1) + '-' + d + '-' + y + ' / ' + disabledDays[i]);
			return [false];
		}
	}
	//console.log('good:  ' + (m+1) + '-' + d + '-' + y);
	
	return [true];
}
function noWeekendsOrHolidays(date) {
	var noWeekend = jQuery.datepicker.noWeekends(date);
	return noWeekend[0] ? nationalDays(date) : noWeekend;
}




	  		$( function() {
	   			$( "#shootdate" ).datepicker({
	   				minDate: 0,
	   				dateFormat:'d-m-yy',
	   				beforeShowDay: nationalDays
	   			});
	  		});
	  	</script>