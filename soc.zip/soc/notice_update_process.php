<?php
// edit data update 
if (isset($_POST['update']))
{

include ('config.php');
	$notice_id=$_POST['notice_id'];
	$notice_subject=$_POST['notice_subject'];
	$notice_con =$_POST['notice_con'];
	$date=$_POST['date'];
	$time=$_POST['time'];
	$notice_sender_name=$_POST['notice_sender_name'];
	$notes=$_POST['notes'];
	

$sql="UPDATE notice SET notice_subject='$notice_subject',notice_con='$notice_con',date='$date',time='$time',notice_sender_name='$notice_sender_name',notes='$notes' WHERE notice_id='$notice_id'";
	 
		echo $sql;
	
	$result=mysql_query($sql);	
	if ($result)
	{
		header("location:notice_send.php?Successfully Update..");
	}
	else 
	{
		echo "<script>alert('Sorry You already Update Data')</script>";
	
	}
	}
	?>

