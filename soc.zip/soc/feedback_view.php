

<?php
include('config.php');
//delete data in tabal

if (isset($_GET['delete'])){
$id = $_GET['delete'];

mysql_query("DELETE FROM feedback WHERE id= '$id'");

header("location:feedback_view.php");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/admin_panel.css" rel="stylesheet">
	<style>
.dropbtn {
  background-color: #222;
  color: white;
  padding: 16px;
  font-size: 14px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>

    <title> Feed Back View</title>
  </head>

  <body>

       <?php
	include('menu.php');
	
	?>
<header id="header">
		<div class="container">
			<div class="row">
				<div class="col-md-10">
					<h1><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>  Feed Back View</h1>
				</div>
				<!--<div class="col-md- create">
					<div class="dropdown">
						  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
							Create Content
							<span class="caret"></span>
						  </button>
						  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
							<li><a type="button" data-toggle="modal" data-target="#addpage">Add Page</a></li>
							<li><a href="#">Add Post</a></li>
							<li><a href="#">Add User</a></li>
						  </ul>
						</div>
				</div>-->
			</div>
		</div>
	</header>
	
	<section id="breadcrumb">
		<div class="container-fluid">
			<ol class="breadcrumb">
				<li>Admin Panel</li>
				<li class="active">  FeedBack View</li>
			</ol>
		</div>
	</section>
	
	


	<section id="main">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12"><!-- website overview -->
					<div class="panel panel-default">
					  <div class="panel-heading main-color-bg">
						<h3 class="panel-title">Feed Back View</h3>
					 </div>
					</div>
					<!-- latest user -->
					<div style="width:1300;height:500px;line-height:3em;overflow:scroll;padding:5px;">

					<div class="panel panel-default">
					  <div class="panel-body">
						<div class="table-responsive">
							<table  class="table table-striped table-hover">
									<tr>
									<th> ID</th>
									<th> Name</th>
									<th>Email ID</th>
									<th>Mobile No</th>
									<th>Messages</th>
									<th>Delete </th>
									
									</tr>

			<?php 
				include('config.php');

				$query ="SELECT * FROM feedback";

				$result=mysql_query($query);

				while($row=mysql_fetch_array($result)){
   
    ?>   
								
								<tr>
								<td><?php echo $row['id'];?></td>
								<td><?php echo $row['name'];?></td>
								<td><?php echo $row['email'];?></td>
								<td><?php echo $row['mobile_no'];?></td>
								
								<td><?php echo $row['msg'];?></td>
								
	<td>										
	<a href="feedback_view.php?delete=<?php echo $row['id'];?>"  onclick="return confirm('Are You Sure Delete Product?');">

		<i class="glyphicon glyphicon-trash" style="font-size:25px" aria-hidden="true"></i>
		<div class="clearfix"></div>

	</a>
	</td>
		
	</tr>

	<?php
		}
	?>

							</table>
							
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	</div>
	<!-- Modal -->
		<div class="modal fade" id="addpage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form>
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Page</h4>
				  </div>
				  <div class="modal-body">
					...
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary">Save changes</button>
				  </div>
				 </form> 
			</div>
		  </div>
		</div>
	
	<!-- footer -->
	


  </body>
</html>
