
<?php include('config.php');

if($_POST['reg']=='submit')
	{  
	$des=$_POST['des'];
	

	$target_dir = "uploads/";
	
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    
		//echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        //echo "Sorry, there was an error uploading your file.";
    }


	$sql="INSERT INTO gallery_photos(photos_des,photos)VALUES('$des','$target_file')";
	
$result = mysql_query($sql);
//echo $sql;

 if($result)
	{
		$msg="You Successfully Add Image";
		header("location:gallery_add.php?msg=".$msg);

   		
} 
    else
    {
		$msg="You ve already Image..";
		header("location:gallery_add.php?msg=".$msg);
		
    }
	}
		
    
	
?>