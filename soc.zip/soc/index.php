		<?php

include('config.php');					
					if(isset($_SESSION['email'])){?>
									<?php
					}
					else 
					{
					header("Location: admin_login.php");

					}
					?>	
			


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/admin_panel.css" rel="stylesheet">
	<style>
.dropbtn {
  background-color: #222;
  color: white;
  padding: 16px;
  font-size: 14px;
  border: none;	
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>

    <title>Dashboard</title>
  </head>

  <body>
 <?php 
		include "menu.php"; 
	?>

	<header id="header">
		<div class="container">
			<div class="row">
				<div class="col-md-10">
					<h1><span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Dashboard</small></h1>
				</div>
			</div>
		</div>
		<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>

	</header>
	

	
	<section id="main">
		<div class="container">
			<div class="row">
				
				<div class="col-md-12"><!-- website overview -->
					<div class="panel panel-default">
					  <div class="panel-heading main-color-bg">
						<h3 class="panel-title"><font color="white"><marquee >WWW.Smart-Society.Com</marquee></font>
			</h3>
						
					 </div>
					 <?php 
include ('config.php');
$user=mysql_query("Select * from member_reg");
$count= mysql_num_rows($user);

$user=mysql_query("Select * from staff");
$count1= mysql_num_rows($user);

$user=mysql_query("Select * from notice");
$count2= mysql_num_rows($user);

$user=mysql_query("Select * from gallery_photos");
$count3= mysql_num_rows($user);

?>
					 <div class="panel-body">
						<div class="col-md-4 col-md-offset-1">
							
							<div class="well dash-box">
								<a href="member_show.php" ><h2><span class="glyphicon glyphicon-user" aria-hidden="true"></span>	
								</h2>
						<h4><?php echo number_format($count) ?></h4>						
							<h4>Total Registered Member</h4></a>
							</div>
							
							<div class="well dash-box">
								<a href="notice_send.php" ><h2><span class="glyphicon glyphicon-comment" aria-hidden="true"></span>
								</h2>
							<h4><?php echo number_format($count2) ?></h4>							
							<h4>Notis Send </h4></a>
							</div>
							
							
						</div>
						<div class="col-md-4 col-md-offset-1">
							<div class="well dash-box">
								<a href="staff.php" ><h2><span class='fas fa-user-friends' aria-hidden="true"></span>	
									
								</h2>
						<h4><?php echo number_format($count1) ?></h4>							
							<h4>Total Staff</h4></a>
							</div>
							
							<div class="well dash-box">
							<a href="gallery_add.php" >	<h2><span class="glyphicon glyphicon-camera" aria-hidden="true"></span>
									
								</h2>
						<h4><?php echo number_format($count3) ?></h4>
														
							<h4>Gallery Photos Add</h4></a>
							</div>
							
							
						</div>
						
							
						
<!--
						<div class="col-md-4 col-md-offset-1">
							<div class="well dash-box">
								<h2><span class="glyphicon glyphicon-tasks" aria-hidden="true"></span> 8</h2>
								<h4>Tables</h4>
							</div>
						</div>
						<div class="col-md-4 col-md-offset-1">
							<div class="well dash-box">
								<h2><span class="glyphicon glyphicon-tasks" aria-hidden="true"></span> 8</h2>
								<h4>Tables</h4>
							</div>
						</div>
						-->
						
					  </div>
					</div>
					<!-- latest user -->
					
				</div>
			</div>
		</div>
	</section>
	
	
	
	<!-- Modal -->
		<div class="modal fade" id="addpage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form>
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Page</h4>
				  </div>
				  <div class="modal-body">
					...
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary">Save changes</button>
				  </div>
				 </form> 
			</div>
		  </div>
		</div>
	<!-- footer -->
	
	
  </body>
</html>
