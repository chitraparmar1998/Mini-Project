<?php
// edit data update 
if (isset($_POST['update']))
{

include ('config.php');

	$staff_id=$_POST['staff_id'];
	$staff_name=$_POST['staff_name'];
	$designation =$_POST['Designation'];
	$email=$_POST['femail'];
	$mobile=$_POST['mobile'];
	$gender=$_POST['gender'];
	

$sql="UPDATE staff SET staff_name='$staff_name',designation='$designation',email='$email',mobile_no='$mobile',gender='$gender' WHERE staff_id='$staff_id'";
	 
		echo $sql;
	
	$result=mysql_query($sql);	
	if ($result)
	{
		header("location:staff.php?Successfully Update..");
	}
	else 
	{
		echo "<script>alert('Sorry You already Update Data')</script>";
	
	}
	}
	?>

