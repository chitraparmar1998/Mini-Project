<?php

include('config.php');					
					if(isset($_SESSION['email'])){?>
									<?php
					}
					else 
					{
					header("Location: admin_login.php");

					}
					?>	


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/admin_panel.css" rel="stylesheet">
	<style>
.dropbtn {
  background-color: #222;
  color: white;
  padding: 16px;
  font-size: 14px;
  border: none;	
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>

    <title>Member Registration</title>
  </head>

  <body>


 <?php
	include('menu.php');
	
	?>
	
	<header id="header">
		<div class="container">
			<div class="row">
				<div class="col-md-10">
					<h1><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>  Member Registration</small></h1>
				</div>
			</div>
		</div>
	</header>
	
	<section id="breadcrumb">
		<div class="container">
			<ol class="breadcrumb">
				<li>Admin Panel</li>
				<li class="active">Member Registration</li>
		</ol>
		</div>
	</section>
	
	<section id="main">
		<div class="container">
			<div class="row">
				<div class="col-md-12"><!-- website overview -->
					<div class="panel panel-default">
					  <div class="panel-heading main-color-bg">
						<h3 class="panel-title">Member Registration</h3>
					 </div>
					</div>
					<!-- latest user -->
					<div class="panel panel-default">
					  <div class="panel-body">
						<div class="table-responsive">
						<form action="member_reg_process.php" method="post" enctype="multipart/form-data">
							<div class="rows">
								
								
								
									<div class="form-group text-left col-md-6">
										<label>Mamber Name :</label>
										<input class="form-control" type="text" name="m_name" required>
									</div>
									
									<div class="form-group text-left col-md-6">
										<label>Email Id :</label>
										<input class="form-control" type="email" name="m_email" required>
									</div>
									
									<div class="form-group text-left col-md-6">
										<label>Address :</label>
										<input class="form-control" type="text" name="address" required>
									</div>
									
								
									<div class="form-group text-left col-md-6">
										<label>Total Mamber :</label>
										<input class="form-control" type="text" name="total_member" required>
									</div>
										<div class="form col-md-6">
										<label>Gender :</label>&nbsp&nbsp&nbsp
										Male&nbsp&nbsp&nbsp <input class="control"  value="male"  type="radio" name="gender" required>&nbsp&nbsp&nbsp
										Female&nbsp&nbsp&nbsp <input class="control"  value="female"  type="radio" name="gender" required>
														
									</div>
									<div class="form col-md-6">
										<label>House Type :</label>&nbsp&nbsp
										1BHK&nbsp&nbsp<input class="control"  value="1BHK"  type="radio" name="house_type" >&nbsp&nbsp&nbsp
										2BHK&nbsp&nbsp <input class="control"  value="2BHK"  type="radio" name="house_type" >&nbsp&nbsp&nbsp
										3BHK&nbsp&nbsp <input class="control"  value="3BHK"  type="radio" name="house_type" >&nbsp&nbsp&nbsp
										4BHK&nbsp&nbsp <input class="control"  value="4BHK"  type="radio" name="house_type" >&nbsp&nbsp&nbsp
										Pent House&nbsp <input class="control"  value="Pent House"  type="radio" name="house_type" >&nbsp&nbsp&nbsp
														
									</div>
									<!--<div class="form-group text-left col-md-6">
										<label>Mamber Image :</label>
										<input class="form-control" type="file" name="fileToUpload" id="fileToUpload" required>
									</div>
									-->
	<?php
		$no1=rand(65,41);
		$no2=rand(65,90);
		$no3=rand(11,99);
		$no4=rand(12,99);
		$no5=rand(65,41);
		$no6=rand(19,99);

		$c2=chr($no2);
		$final_number=$c2.$no3.$no4.$no5.$no6;	
		
?>

									<div class="form-group text-left col-md-6">
										<label>Password :</label>
										<input class="form-control" type="text" value ="<?php echo $final_number;?>" name="password" required>
									</div>
										<div class="form-group text-left col-md-6">
										<label>Mobile Number :</label>
										<input class="form-control" type="text" name="mobile" required>
									</div>
																																				
									<br><br><br><br>
									
									
									<div class="form-group text-left col-md-4">
										<input class="btn btn-primary" type="submit" name="reg" value="submit">
									<!--MSG PASS-------->
										<h4 style="color:red;">
										<?php 
										  if (isset($_GET['msg'])) echo $_GET['msg'];
											
										?>
										
											</h4>							
								
									</div>
								</div>
							</form>	
					
							
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<!-- Modal -->
		<div class="modal fade" id="addpage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form>
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Page</h4>
				  </div>
				  <div class="modal-body">
					...
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary">Save changes</button>
				  </div>
				 </form> 
			</div>
		  </div>
		</div>
	<!-- footer -->
	
	
  </body>
</html>
